# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9762df24ed0bd5f0878e0c53fe04c4c41ed44edcc65f46ec64a20705955fd8c84b7ad426316b855fda1bfbeb02ee1dc99643eb526c295a47407ba47878dc0405'
